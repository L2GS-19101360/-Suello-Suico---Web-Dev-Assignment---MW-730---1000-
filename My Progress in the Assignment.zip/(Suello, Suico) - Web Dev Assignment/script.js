var myBooks = [
    {id: 1, title: 'A Handbook of Agile Software Craftsmanship', author: 'Robert C. Martin', year: 1969, publisher: 'Prentice Hall'},
    {id: 2, title: 'Introduction to Algorithms', author: 'Thomas H. Cormen', year: 2002, publisher: 'MIT Press'},
    {id: 3, title: 'Structure and Interpretation of Computer Programs (SICP)', author: 'Harold Abelson', year: 1998, publisher: 'MIT Press'},
    {id: 4, title: 'A Code of Conduct for Professional Programmers', author: 'Robert C. Martin', year: 1969, publisher: 'Prentice Hall'},
    {id: 5, title: 'A Practical Handbook of Software Construction', author: 'Steve McConnell', year: 2000, publisher: 'Microsoft Press'},
    {id: 6, title: 'Elements of Reusable Object-Oriented Software', author: 'Enrich Gamma', year: 2004, publisher: 'Addison-Wesley Professional'},
    {id: 7, title: 'The Pragmatic Programmer', author: 'Andrew Hunt', year: 1995, publisher: 'Addison-Wesley Professional'},
    {id: 8, title: 'Improving the Design of Existing Code', author: 'Martin Fowler', year: 1990, publisher: 'Addison-Wesley Professional'},
    {id: 9, title: 'The Art of Computer Programming', author: 'Donald E. Knuth', year: 1990, publisher: 'Addison-Wesley Professional'},
    {id: 10, title: 'Patterns of Enterprise Application Architecture', author: 'Martin Fowler', year: 1990, publisher: 'Addison-Wesley Professional'}
]

function testFunc(){
    console.log("Clicked");
}

function funcCall(){
    var html = "<table>"
    html += '<thead>';
    html += '<tr>';
        html += '<td style="background-color: #45a049;">'+'Book ID'+'</td>';
        html += '<td style="background-color: #45a049;">'+'Book Title'+'</td>';
        html += '<td style="background-color: #45a049;">'+'Book Author'+'</td>';
        html += '<td style="background-color: #45a049;">'+'Publish Year'+'</td>';
        html += '<td style="background-color: #45a049;">'+'Publisher'+'</td>';                
    html += '<tr>';
    html += '</thead>';
    setTimeout(() => {
        for (var i = 0; i < myBooks.length; i++){
            html += '<tr>';
                html += '<td>'+myBooks[i].id+'</td>';
                html += '<td>'+myBooks[i].title+'</td>';
                html += '<td>'+myBooks[i].author+'</td>';
                html += '<td>'+myBooks[i].year+'</td>';
                html += '<td>'+myBooks[i].publisher+'</td>';
            html += '</tr>';
        }
        document.getElementById("table_of_books").innerHTML = html;
    }, 500);
}

funcCall();

function search(){
    var inputID = document.getElementById("input").value;
    var outputID = document.getElementById("search_result");

    for (var i = 0; i < myBooks.length; i++){
        if (myBooks[i].id == inputID){
            outputID.innerHTML = "Book ID " + inputID + " Found<br><br><br>" + 
                "Book ID: " + myBooks[i].id + "<br><br>" + 
                "Book Title: " + myBooks[i].title + "<br><br>" +
                "Book Author: " + myBooks[i].author + "<br><br>" +
                "Publish Year: " + myBooks[i].year + "<br><br>" +
                "Publisher: " + myBooks[i].publisher + "<br><br>";
            return
        }
    }

    outputID.innerHTML = "Book ID " + inputID + " Not Found";
}

function searchToDelete(){
    var inputDelete = document.getElementById("inputToDelete").value
    var resDelete = document.getElementById("search_resultDelete");

    for (var i = 0; i < myBooks.length; i++){
        if (myBooks[i].id == inputDelete){
            resDelete.innerHTML = "Book ID " + inputDelete + " Found<br><br><br>" + 
                "Book ID: " + myBooks[i].id + "<br><br>" + 
                "Book Title: " + myBooks[i].title + "<br><br>" +
                "Book Author: " + myBooks[i].author + "<br><br>" +
                "Publish Year: " + myBooks[i].year + "<br><br>" +
                "Publisher: " + myBooks[i].publisher + "<br><br>" +
                `<button onclick="deleteBook(${myBooks[i].id})" style="background-color: red; padding:5px; width:100px; border-radius:10%;">Delete Book</button>`;
                return;
        }
    }
    resDelete.innerHTML = "Book ID " + inputDelete + " Not Found";
}

function deleteBook(getVal){
    // console.log(getVal);
    var filterBook = myBooks.filter((a,i) => {
        if (getVal == a.id){
            myBooks.splice(i, 1);
            funcCall();
            searchToDelete();
        }
    });
}



function displayBooks() {
    const bookList = document.getElementById("book-list");
    bookList.innerHTML = "";

    for (let i = 0; i < myBooks.length; i++) {
      const book = myBooks[i];

      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${myBooks.cardID}</td>
        <td>${myBooks.bookTitle}</td>
        <td>${myBooks.bookAuthor}</td>
        <td>${myBooks.yearPublished}</td>
        <td>${myBooks.publisher}</td>
      `;

      bookList.appendChild(row);
    }
  }

  displayBooks();